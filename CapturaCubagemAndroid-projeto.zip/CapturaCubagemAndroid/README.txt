CAPTURA & CUBAGEM - Projeto Android

Este projeto já contém o arquivo captura_cubagem_web.html embutido em app/src/main/assets/index.html.
Nome do app: Captura & Cubagem
Pacote: com.didoflores.capturacubagem
Compatibilidade: Android 8.0 (API 26) ou superior.

Para gerar o APK em um computador com Android Studio:
1. Abra esta pasta no Android Studio.
2. Aguarde o Gradle sincronizar.
3. Menu Build > Build APK(s).
4. O APK ficará em app/build/outputs/apk/debug/app-debug.apk.

O app usa WebView local e mantém IndexedDB/armazenamento local do programa.
A câmera/seletor de imagens é tratado pelo aplicativo Android.

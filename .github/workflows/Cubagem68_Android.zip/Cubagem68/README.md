# Cubagem 68

Aplicativo Android offline para calcular a cubagem de produtos em um contêiner configurado para 68 m³.

## Versão 1
- Foto do produto pela câmera
- Nome/código
- Comprimento, largura e altura da caixa em cm
- Quantidade de caixas
- Cubagem automática por caixa e total
- Indicador de volume usado e restante
- Novo contêiner
- Total salvo localmente no celular

## Gerar APK
Abra o projeto no Android Studio no computador e use Build > Build APK(s).

package com.didoflores.cubagem68

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private val limite = 68.0
    private var total = 0.0
    private lateinit var resumo: TextView
    private lateinit var progresso: ProgressBar
    private lateinit var lista: LinearLayout
    private lateinit var foto: ImageView
    private val prefs by lazy { getSharedPreferences("cubagem68", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        resumo = findViewById(R.id.txtResumo)
        progresso = findViewById(R.id.progresso)
        lista = findViewById(R.id.lista)
        foto = findViewById(R.id.foto)

        total = prefs.getFloat("total", 0f).toDouble()
        atualizar()

        findViewById<Button>(R.id.btnFoto).setOnClickListener {
            startActivityForResult(Intent(MediaStore.ACTION_IMAGE_CAPTURE), 10)
        }

        findViewById<Button>(R.id.btnAdicionar).setOnClickListener { adicionar() }

        findViewById<Button>(R.id.btnNovo).setOnClickListener {
            total = 0.0
            prefs.edit().clear().apply()
            lista.removeAllViews()
            atualizar()
            Toast.makeText(this, "Novo contêiner iniciado", Toast.LENGTH_SHORT).show()
        }
    }

    private fun numero(id: Int): Double =
        findViewById<EditText>(id).text.toString().replace(",", ".").toDoubleOrNull() ?: 0.0

    private fun adicionar() {
        val nome = findViewById<EditText>(R.id.nome).text.toString().ifBlank { "Produto" }
        val c = numero(R.id.comprimento)
        val l = numero(R.id.largura)
        val a = numero(R.id.altura)
        val q = numero(R.id.quantidade).toInt()
        if (c <= 0 || l <= 0 || a <= 0 || q <= 0) {
            Toast.makeText(this, "Preencha medidas e quantidade", Toast.LENGTH_SHORT).show()
            return
        }
        val porCaixa = (c * l * a) / 1_000_000.0
        val produtoTotal = porCaixa * q
        total += produtoTotal
        prefs.edit().putFloat("total", total.toFloat()).apply()

        val item = TextView(this)
        item.text = "$nome\n$q caixas • ${fmt(porCaixa)} m³/caixa • TOTAL ${fmt(produtoTotal)} m³"
        item.textSize = 16f
        item.setPadding(8, 14, 8, 14)
        lista.addView(item, 0)
        atualizar()
        Toast.makeText(this, "Produto adicionado", Toast.LENGTH_SHORT).show()
    }

    private fun atualizar() {
        val restante = limite - total
        val pct = (total / limite * 100).coerceAtLeast(0.0)
        resumo.text = "${fmt(total)} / 68,000 m³\nRestante: ${fmt(restante)} m³ • ${String.format(Locale.getDefault(),"%.1f",pct)}%"
        progresso.progress = (total * 1000).toInt().coerceAtMost(68000)
    }

    private fun fmt(v: Double) = String.format(Locale.getDefault(), "%.3f", v)

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 10 && resultCode == Activity.RESULT_OK) {
            val bmp = data?.extras?.get("data") as? Bitmap
            if (bmp != null) {
                foto.setImageBitmap(bmp)
                foto.visibility = View.VISIBLE
            }
        }
    }
}
